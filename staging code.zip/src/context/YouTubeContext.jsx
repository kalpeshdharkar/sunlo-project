import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';

const API_KEY = 'AIzaSyBoiW6hToj0rtnSGm4QOIEuH59yeT_z_Bg'; // replace with your actual key
const BASE_URL = 'https://www.googleapis.com/youtube/v3';

const YouTubeContext = createContext();
export const useYouTube = () => useContext(YouTubeContext);

export const YouTubeProvider = ({ children }) => {
  const [videos, setVideos] = useState([]);
  const [currentVideoId, setCurrentVideoId] = useState(null);

  useEffect(() => {
    axios.get(`${BASE_URL}/videos`, {
      params: {
        part: 'snippet,contentDetails',
        chart: 'mostPopular',
        regionCode: 'IN',
        maxResults: 20,
        key: API_KEY,
      },
    }).then(res => setVideos(res.data.items))
      .catch(console.error);
  }, []);

  const searchVideos = async (query) => {
    if (!query || query.trim().length === 0) return;
    try {
      const res = await axios.get(`${BASE_URL}/search`, {
        params: {
          part: 'snippet',
          q: query,
          type: 'video',
          maxResults: 20,
          key: API_KEY,
        },
      });
      setVideos(res.data.items);
    } catch (err) {
      console.error('Search videos error:', err);
    }
  };

  return (
    <YouTubeContext.Provider value={{ videos, currentVideoId, setCurrentVideoId, searchVideos }}>
      {children}
    </YouTubeContext.Provider>
  );
};
