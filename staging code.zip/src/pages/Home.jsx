import React from 'react';
import MainPage from '../components/Resso/MainPage'; // Path must be correct

const Home = () => {
  return <MainPage />;
};

export default Home;
