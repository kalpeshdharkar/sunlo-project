import React from 'react';

const Player = () => {
  return (
    <div className="p-6 text-white">
      <h1 className="text-3xl font-bold mb-4">Player</h1>
      <p>This is the Player screen.</p>
    </div>
  );
};

export default Player;
