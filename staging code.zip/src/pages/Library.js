import React from 'react';

const Library = () => {
  return (
    <div className="p-6 text-white">
      <h1 className="text-3xl font-bold mb-4">Library</h1>
      <p>This is the Library screen.</p>
    </div>
  );
};

export default Library;
