import React from 'react';

const Search = () => {
  return (
    <div className="p-6 text-white">
      <h1 className="text-3xl font-bold mb-4">Search Page</h1>
      <p>This is the Search Page.</p>
    </div>
  );
};

export default Search;
