import React from 'react';
import YouTubeView from '../YouTube/YouTubeView';
import YouTubePlayer from '../YouTube/YouTubePlayer';
import SearchBar from '../SearchBar'; // ✅ Correct import path (from 'components/Resso' folder)

const MainPage = () => {
  return (
    <div className="relative min-h-screen bg-gray-950 text-white p-4">
      {/* Header */}
      <header className="text-center text-4xl font-bold py-4 text-purple-400">
        🎵 Sunlo - YouTube Music
      </header>

      {/* Search Bar */}
      <div className="flex justify-center my-4">
        <SearchBar />
      </div>

      {/* Main Content */}
      <YouTubeView />

      {/* Persistent Floating YouTube Player */}
      <YouTubePlayer />
    </div>
  );
};

export default MainPage;
