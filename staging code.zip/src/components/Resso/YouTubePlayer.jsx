import React from 'react';
import { useYouTube } from '../../context/YouTubeContext';

const YouTubePlayer = () => {
  const { currentVideoId, setCurrentVideoId, playNextVideo } = useYouTube();

  if (!currentVideoId) return null;

  const handleClose = () => {
    setCurrentVideoId(null); // stop video and hide player
  };

  const handleNext = () => {
    playNextVideo(); // logic should be in context
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 bg-black p-2 rounded-xl shadow-lg">
      <div className="flex justify-between items-center mb-2 px-2">
        <button
          onClick={handleClose}
          className="text-white bg-red-600 px-3 py-1 rounded hover:bg-red-700 transition"
        >
          Close
        </button>
        <button
          onClick={handleNext}
          className="text-white bg-blue-600 px-3 py-1 rounded hover:bg-blue-700 transition"
        >
          Next
        </button>
      </div>

      <div className="aspect-video w-full">
        <iframe
          key={currentVideoId}
          className="rounded-lg w-full h-full"
          src={`https://www.youtube.com/embed/${currentVideoId}?autoplay=1&mute=1`}
          title="YouTube player"
          allow="autoplay; encrypted-media"
          allowFullScreen
        ></iframe>
      </div>
    </div>
  );
};

export default YouTubePlayer;
