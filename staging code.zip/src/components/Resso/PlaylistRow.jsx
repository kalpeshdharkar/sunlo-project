import React from 'react';

const PlaylistRow = ({ title }) => {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">{title}</h2>
      <div className="flex overflow-x-auto space-x-4 pb-2">
        {[1, 2, 3, 4, 5].map((i) => (
          <div
            key={i}
            className="min-w-[150px] bg-gray-800 rounded-lg p-2 flex-shrink-0"
          >
            <div className="h-24 bg-gray-700 rounded-md mb-2"></div>
            <p className="text-sm font-medium">Song Title {i}</p>
            <p className="text-xs text-gray-400">Artist Name</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PlaylistRow;
