import React from 'react';
import YouTubePlaylistPlayer from './YouTubePlaylistPlayer';

const MainPage = () => {
  return <YouTubePlaylistPlayer />;
};

export default MainPage;
