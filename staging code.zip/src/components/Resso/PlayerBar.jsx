import React from 'react';
import { Play, SkipForward, SkipBack } from 'lucide-react';

const PlayerBar = () => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900 p-4 flex items-center justify-center gap-6 border-t border-gray-700">
      <SkipBack className="w-5 h-5 cursor-pointer" />
      <Play className="w-8 h-8 cursor-pointer text-pink-500" />
      <SkipForward className="w-5 h-5 cursor-pointer" />
    </div>
  );
};

export default PlayerBar;
