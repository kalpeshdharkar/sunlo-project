import React from 'react';
import { useYouTube } from '../../context/YouTubeContext';

const YouTubePlayer = () => {
  const { currentVideoId } = useYouTube();

  if (!currentVideoId) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 bg-black/70 backdrop-blur-lg p-2 rounded-xl shadow-xl border border-white/10">
      <div className="aspect-video w-full">
        <iframe
          key={currentVideoId}
          className="rounded-lg w-full h-full"
          src={`https://www.youtube.com/embed/${currentVideoId}?autoplay=1&mute=1`}
          title="YouTube player"
          allow="autoplay; encrypted-media"
          allowFullScreen
        ></iframe>
      </div>
    </div>
  );
};

export default YouTubePlayer;
